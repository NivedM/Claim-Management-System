/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.services;

import tech.cts.admin.model.admin;

/**
 *
 * @author 2046523
 */
//to store footprint of logAdmin
public interface AdminService {
    public admin logAdmin(String mail_id,String password );
}
