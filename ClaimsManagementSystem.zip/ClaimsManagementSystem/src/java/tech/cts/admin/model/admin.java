/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.model;

/**
 *
 * @author 2046523
 */
public class admin {
    private int admin_id;
    private String first_name;
    private String last_name;
    private String mail_id;
    private String role;
    private String password;

    public admin() {
    }

    public admin(int admin_id, String first_name, String last_name, String mail_id, String role, String password) {
        this.admin_id = admin_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.mail_id = mail_id;
        this.role = role;
        this.password = password;
    }

    public admin(String mail_id, String role, String password) {
        this.mail_id = mail_id;
        this.role = role;
        this.password = password;
    }

    public int getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(int admin_id) {
        this.admin_id = admin_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getMail_id() {
        return mail_id;
    }

    public void setMail_id(String mail_id) {
        this.mail_id = mail_id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}
