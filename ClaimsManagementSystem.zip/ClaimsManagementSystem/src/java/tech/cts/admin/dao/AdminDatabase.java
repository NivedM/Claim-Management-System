/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.dao;
import java.sql.*;
import tech.cts.admin.model.admin;
import tech.cts.admin.services.AdminService;
/**
 *
 * @author 2046523
 */
public class AdminDatabase implements AdminService {
    private Connection con;
    private String query;
    private PreparedStatement pst;
    private ResultSet rs;

    public AdminDatabase(Connection con) {
        this.con = con;
    }
    
    @Override
    public admin logAdmin(String mail_id,String password){
        admin ad=null;
        try{
        query="select * from user_master where mail_id=? and password=?";
        pst=this.con.prepareStatement(query);
        pst.setString(1, mail_id);
        pst.setString(2,password);
        rs=pst.executeQuery();
        if(rs.next()){
                ad= new admin();
                ad.setAdmin_id(rs.getInt("admin_id"));
                ad.setFirst_name(rs.getString("first_name"));
                ad.setLast_name(rs.getString("last_name"));
                ad.setMail_id(rs.getString("mail_id"));
                ad.setRole(rs.getString("role"));
        }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return ad;
        
    }
    
}
