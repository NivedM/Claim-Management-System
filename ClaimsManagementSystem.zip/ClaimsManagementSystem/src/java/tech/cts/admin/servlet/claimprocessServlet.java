/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import newpackage.ConnectionPro;
import newpackage.User;
import newpackage.UserDatabase;

public class claimprocessServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet claimprocessServlet</title>");
            out.println("</head>");
            out.println("<body>");
            //fetch data from registration page
            String cust_id = request.getParameter("cust_id");
            String claim_id = request.getParameter("claim_id");
            String doc1 = request.getParameter("doc1");
            String doc2 = request.getParameter("doc2");
            String doc3 = request.getParameter("doc3");
            String decision = request.getParameter("decision");
            String reject_reason = request.getParameter("reject_reason");
            String final_claim_amount = request.getParameter("demoa");
            String claim_status = request.getParameter("decision");
            
            //String updated_by;
            //LocalDate amount_aval_date=LocalDate.now().plusDays(10);

            //make user object
            User userModel = new User(cust_id, claim_id, doc1, doc2, doc3, decision, reject_reason, final_claim_amount, claim_status/*,updated_by*/);

            //create a database model and get connection
            UserDatabase regUser = new UserDatabase(ConnectionPro.getConnection());

            if (regUser.processUser(userModel)) {
                //response.sendRedirect("adminpanel.jsp");
                LocalDate amount_aval_date = LocalDate.now().plusDays(10);
                if ("Approved".equals(claim_status)) {
                    request.setAttribute("msg", "Dear Admin, the final amount of " + final_claim_amount + "  will be available on " + (amount_aval_date));
                } else {
                    request.setAttribute("msg", "Dear Admin, claim rejected for " + cust_id);
                }
                request.getRequestDispatcher("adminpanel.jsp").forward(request, response);
            }
            else {
                String errorMessage = "Check details";
                HttpSession regSession = request.getSession();
                regSession.setAttribute("RegisError", errorMessage);
                response.sendRedirect("memberclaimprocess.jsp");
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
