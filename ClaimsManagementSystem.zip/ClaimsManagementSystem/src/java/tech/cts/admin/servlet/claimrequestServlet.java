/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import newpackage.ConnectionPro;
import newpackage.User;
import newpackage.UserDatabase;
import java.time.LocalDate;

/**
 *
 * @author 2046523
 */
public class claimrequestServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
            /* TODO output your page here. You may use following sample code. */
           
    }

    
     
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet claimrequestServlet</title>");
            out.println("</head>");
            out.println("<body>");
            
            //fetch data from registration page
            String cust_id=request.getParameter("cust_id");
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            String nominee_count = request.getParameter("nominee_count");
            
            String insurance_type = request.getParameter("insurance_type");
            String claim_reason=request.getParameter("claim_reason");
            String insurance_amount = request.getParameter("insurance_amount");
            String maxi = request.getParameter("demo");
            String final_claim_amount = request.getParameter("demoa");
            String request_date = request.getParameter("reqdte");

            //make user object
            User userModel = new User(cust_id,fname, lname,  nominee_count, insurance_type,claim_reason,insurance_amount,maxi,final_claim_amount, request_date);

            //create a database model and get connection
            UserDatabase regUser = new UserDatabase(ConnectionPro.getConnection());
            int claim_id=regUser.claimUser(userModel);
            if (claim_id >0){
                
                //response.sendRedirect("adminpanel.jsp");
                LocalDate req=LocalDate.now().plusDays(45);
                request.setAttribute("msg", "Dear Admin,the claim request for " + cust_id +" has been posted.Your claim id " + claim_id + "  will be processed before "+(req));
                request.getRequestDispatcher("adminpanel.jsp").forward(request, response);
                
     
                
            } else {
                
                String errorMessage = "User Available";
                HttpSession regSession = request.getSession();
                regSession.setAttribute("RegsError", errorMessage);
                response.sendRedirect("memberclaimrequest.jsp");
                out.println("<script type=\"text/javascript\">");
                out.println("alert('User already registered');");
                out.println("</script>");
                
            }
        }
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
