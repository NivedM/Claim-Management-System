/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.servlet;

import com.mysql.cj.protocol.Resultset;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import newpackage.ConnectionPro;

/**
 *
 * @author 2046523
 */
public class getautovalue extends HttpServlet {

    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String cust_id = request.getParameter("cust_id");
            con = ConnectionPro.getConnection();
            pst=con.prepareStatement("SELECT * FROM USER WHERE cust_id = ?");
            pst.setString(1,cust_id);
            rs=pst.executeQuery();
            //st = con.createStatement();
            //rs = st.executeQuery("select * from user where cust_id=" + cust_id + "");

            while (rs.next()) {
                PrintWriter out=response.getWriter();
                out.print(rs.getString("fname") + "," + rs.getString("lname") + "," + rs.getString("cno") + "," + rs.getString("email") + "," + rs.getString("Gender") + "," + rs.getString("dob") + "," + rs.getString("addr") + "," + rs.getString("nominee_count") + "," + rs.getString("insurance_type") + "," + rs.getString("insurance_amount"));
            }
        } 
        catch (Exception e) {
            out.println(e);
        }
    }

    

}
