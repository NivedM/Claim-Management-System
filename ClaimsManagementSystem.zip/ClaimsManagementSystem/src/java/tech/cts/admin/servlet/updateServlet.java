
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import newpackage.ConnectionPro;
import newpackage.ConnectionPro;
import newpackage.User;
import newpackage.User;
import newpackage.UserDatabase;
import newpackage.UserDatabase;
import tech.cts.admin.model.admin;




/**
 *
 * @author 2046523
*/ 
public class updateServlet extends HttpServlet {

 

    /*
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (PrintWriter out = response.getWriter()) {
            ConnectionPro db = new ConnectionPro();
            HttpSession session = request.getSession(true);
            admin admi = (admin) session.getAttribute("loggedAdmin");
                
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet updateServlet</title>");
                out.println("</head>");
                out.println("<body>");
                //fetch data from registration page
                
                String cust_id=request.getParameter("cust_id");
                System.out.print(cust_id);
                String fname = request.getParameter("fname");
                System.out.print(fname);
                String lname = request.getParameter("lname");
                System.out.print(lname);
                String cno = request.getParameter("cno");
                System.out.print(cno);
                String email = request.getParameter("email");
                System.out.print(email);
                String Gender = request.getParameter("Gender");
                System.out.print(Gender);
                String dob = request.getParameter("dob");
                System.out.print(dob);
                String addr = request.getParameter("newaddr");

                String nominee_count = request.getParameter("nominee_count");
                String insurance_type = request.getParameter("insurance_type");
                String insurance_amount = request.getParameter("insurance_amount");

                String maxi = request.getParameter("demo");
                
                String password = request.getParameter("password");
                //String updated_by=request.getParameter("loggedAdmin");

                //make user object
                User userModel = new User(cust_id,fname, lname, cno, email, Gender, dob, addr, nominee_count, insurance_type, insurance_amount, maxi,password/*,updated_by*/);

                //create a database model and get connection
                UserDatabase regUser = new UserDatabase(ConnectionPro.getConnection());
                if (regUser.updateUser(userModel)) {
                   //response.sendRedirect("adminpanel.jsp");
               
        
                request.setAttribute("msg", "Dear Admin,the member " + cust_id +" has been updated successfully");
                request.getRequestDispatcher("adminpanel.jsp").forward(request, response);
                    
                    //out.println("alert('<h1>Dear admin,<br/> The member <mem id> updated successfully!');"); 
                } else {
                    String errorMessage = "User Available";
                    HttpSession regSession = request.getSession();
                    regSession.setAttribute("RegisError", errorMessage);
                    response.sendRedirect("memberupdate.jsp");
                }
                

         

        //String name=request.getParameter("MEMBER_ID"); 

        

    
            }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
