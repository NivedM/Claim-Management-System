/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech.cts.admin.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import newpackage.ConnectionPro;

/**
 *
 * @author 2046523
 */
public class idcheckServlet extends HttpServlet {

    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    
   
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String cust_id=request.getParameter("cust_id");
        try{
            conn=ConnectionPro.getConnection();
            pst=conn.prepareStatement("SELECT * FROM claim_process WHERE cust_id=?");
            pst.setString(1,cust_id);
            rs=pst.executeQuery();
            
            if(rs.next()){
                response.setContentType("text/html");
                PrintWriter out=response.getWriter();
                out.println("Claim for this user already exists");
            }
            else{
                response.setContentType("text/html");
                PrintWriter out=response.getWriter();
                out.print("");
                
            }
        }
        
        catch(Exception e){
            e.getMessage();
                    
       }
       
    }
}