
package newpackage;

import com.mysql.cj.protocol.Resultset;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class emailcheckServlet extends HttpServlet {
    
    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    
   
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email=request.getParameter("email");
        try{
            conn=ConnectionPro.getConnection();
            pst=conn.prepareStatement("SELECT * FROM USER WHERE email=?");
            pst.setString(1,email);
            rs=pst.executeQuery();
            
            if(rs.next()){
                response.setContentType("text/html");
                PrintWriter out=response.getWriter();
                out.println("Already Exists");
            }
            else{
                response.setContentType("text/html");
                PrintWriter out=response.getWriter();
                out.print("");
                
            }
        }
        
        catch(Exception e){
            e.getMessage();
                    
       }
       
    }

  
    

}
