package newpackage;

//import java.sql.Date;
import java.util.*;
import java.time.LocalDate;

public class User {

    String cust_id;
    String fname;
    String lname;
    String cno;
    String email;
    String Gender;
    String dob;
    String addr;
    String nominee_count;
    String insurance_type;
    String insurance_amount;
    private String maxi;

   
    String password;
    String request_date;
    String claim_id;
    String claim_reason;
    String final_claim_amount;
    private String doc1;
    private String doc2;
    private String doc3;
    private String decision;
    private String reject_reason;

    String claim_status;

    String updated_by;
   
   // Date amount_aval_date;

    public User() {
    }

    public User(String cust_id, String fname, String lname, String cno, String email, String Gender, String dob, String addr, String nominee_count, String insurance_type, String insurance_amount, String maxi, String password/*,String updated_by*/) {
        this.cust_id = cust_id;
        this.fname = fname;
        this.lname = lname;
        this.cno = cno;
        this.email = email;
        this.Gender = Gender;
        this.dob = dob;
        this.addr = addr;
        this.nominee_count = nominee_count;
        this.insurance_type = insurance_type;
        this.insurance_amount = insurance_amount;
        this.maxi = maxi;
        this.password = password;
        //this.updated_by=updated_by;

    }

    public User(String cust_id, String fname, String lname, String nominee_count, String insurance_type, String claim_reason, String insurance_amount, String maxi, String final_claim_amount, String request_date/*,String updated_by*/) {
        this.cust_id = cust_id;
        this.fname = fname;
        this.lname = lname;
        this.nominee_count = nominee_count;
        this.insurance_type = insurance_type;
        this.claim_reason = claim_reason;
        this.insurance_amount = insurance_amount;
        this.maxi = maxi;
        this.final_claim_amount = final_claim_amount;
        this.request_date = request_date;
        //this.updated_by=updated_by;

    }

    public User(String fname, String lname, String cno, String email, String Gender, String dob, String addr, String nominee_count, String insurance_type, String insurance_amount, String maxi, String password/*,String updated_by*/) {
        this.fname = fname;
        this.lname = lname;
        this.cno = cno;
        this.email = email;
        this.Gender = Gender;
        this.dob = dob;
        this.addr = addr;
        this.nominee_count = nominee_count;
        this.insurance_type = insurance_type;
        this.insurance_amount = insurance_amount;
        this.maxi = maxi;
        this.password = password;
        //this.updated_by=updated_by;

    }

    public User(String fname, String lname, String cno, String email, String Gender, String dob, String addr, String nominee_count, String insurance_type, String insurance_amount, String maxi/*,String updated_by*/) {
        this.fname = fname;
        this.lname = lname;
        this.cno = cno;
        this.email = email;
        this.Gender = Gender;
        this.dob = dob;
        this.addr = addr;
        this.nominee_count = nominee_count;
        this.insurance_type = insurance_type;
        this.insurance_amount = insurance_amount;
        this.maxi = maxi;
        //this.updated_by=updated_by;

    }
    
     public User(String cust_id, String claim_id, String doc1, String doc2, String doc3, String decision, String reject_reason,String final_claim_amount,String claim_status/*,String updated_by*/) {
        this.cust_id = cust_id;
        this.claim_id = claim_id;
        this.doc1 = doc1;
        this.doc2 = doc2;
        this.doc3 = doc3;
        this.decision = decision;
        this.reject_reason = reject_reason;
        this.claim_status=claim_status;
       // this.updated_by=updated_by;
        //this.final_claim_amount = final_claim_amount;
        
    }

    /**
     *
     * @param email
     * @param password
     */
    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }

    /**
     * @return the cust_id
     */
    public String getCust_id() {
        return cust_id;
    }

    /**
     * @param cust_id the cust_id to set
     */
    public void setCust_id(String cust_id) {
        this.cust_id = cust_id;
    }

    /**
     * @return the fname
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }

    /**
     * @return the lname
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the lname to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    /**
     * @return the cno
     */
    public String getCno() {
        return cno;
    }

    /**
     * @param cno the cno to set
     */
    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the Gender
     */
    public String getGender() {
        return Gender;
    }

    /**
     * @param Gender the Gender to set
     */
    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    /**
     * @return the dob
     */
    public String getDob() {
        return dob;
    }

    /**
     * @param dob the dob to set
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * @return the addr
     */
    public String getAddr() {
        return addr;
    }

    /**
     * @param addr the addr to set
     */
    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the nominee_count
     */
    public String getNominee_count() {
        return nominee_count;
    }

    /**
     * @param nominee_count the nominee_count to set
     */
    public void setNominee_count(String nominee_count) {
        this.nominee_count = nominee_count;
    }

    /**
     * @return the insurance_type
     */
    public String getInsurance_type() {
        return insurance_type;
    }

    /**
     * @param insurance_type the insurance_type to set
     */
    public void setInsurance_type(String insurance_type) {
        this.insurance_type = insurance_type;
    }

    /**
     * @return the insurance_amount
     */
    public String getInsurance_amount() {
        return insurance_amount;
    }

    /**
     * @param insurance_amount the insurance_amount to set
     */
    public void setInsurance_amount(String insurance_amount) {
        this.insurance_amount = insurance_amount;
    }

    /**
     * @return the maxi
     */
    public String getMaxi() {
        return maxi;
    }

    /**
     * @param maxi the maxi to set
     */
    public void setMaxi(String maxi) {
        this.maxi = maxi;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }

    public String getClaim_id() {
        return claim_id;
    }

    public void setClaim_id(String claim_id) {
        this.claim_id = claim_id;
    }

    public String getClaim_reason() {
        return claim_reason;
    }

    public void setClaim_reason(String claim_reason) {
        this.claim_reason = claim_reason;
    }

    public String getFinal_claim_amount() {
        return final_claim_amount;
    }

    public void setFinal_claim_amount(String final_claim_amount) {
        this.final_claim_amount = final_claim_amount;
    }

    /**
     * @return the doc1
     */
    public String getDoc1() {
        return doc1;
    }

    /**
     * @param doc1 the doc1 to set
     */
    public void setDoc1(String doc1) {
        this.doc1 = doc1;
    }

    /**
     * @return the doc2
     */
    public String getDoc2() {
        return doc2;
    }

    /**
     * @param doc2 the doc2 to set
     */
    public void setDoc2(String doc2) {
        this.doc2 = doc2;
    }

    /**
     * @return the doc3
     */
    public String getDoc3() {
        return doc3;
    }

    /**
     * @param doc3 the doc3 to set
     */
    public void setDoc3(String doc3) {
        this.doc3 = doc3;
    }

    /**
     * @return the decision
     */
    public String getDecision() {
        return decision;
    }

    /**
     * @param decision the decision to set
     */
    public void setDecision(String decision) {
        this.decision = decision;
    }

    /**
     * @return the reject_reason
     */
    public String getReject_reason() {
        return reject_reason;
    }

    /**
     * @param reject_reason the reject_reason to set
     */
    public void setReject_reason(String reject_reason) {
        this.reject_reason = reject_reason;
    }
       public String getUpdated_by() {
        return updated_by;
    }

    public void setUpdated_by(String updated_by) {
        this.updated_by = updated_by;
    }
    
    public String getClaim_status() {
        return claim_status;
    }

    public void setClaim_status(String claim_status) {
        this.claim_status = claim_status;
    }

  
     /* public String getAmount_aval_date() {
        return amount_aval_date;
    }

    public void setAmount_aval_date(String amount_aval_date) {
        this.amount_aval_date = amount_aval_date;
    }*/

}
