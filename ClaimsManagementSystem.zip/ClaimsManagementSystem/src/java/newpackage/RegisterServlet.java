package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author 2046523
 */
public class RegisterServlet extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterServlet</title>");
            out.println("</head>");
            out.println("<body>");
            //fetch data from registration page
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            String cno = request.getParameter("cno");
            String email = request.getParameter("email");
            String Gender = request.getParameter("Gender");
            String dob = request.getParameter("dob");
            String addr = request.getParameter("newaddr");

            String nominee_count = request.getParameter("nominee_count");
            String insurance_type = request.getParameter("insurance_type");
            String insurance_amount = request.getParameter("insurance_amount");

            String maxi = request.getParameter("demo");
            
            String password = request.getParameter("password");

            //make user object
            User userModel = new User(fname, lname, cno, email, Gender, dob, addr, nominee_count, insurance_type, insurance_amount, maxi, password);

            //create a database model and get connection
            UserDatabase regUser = new UserDatabase(ConnectionPro.getConnection());
            if (regUser.saveUser(userModel)) {
                    request.setAttribute("msg", "Dear " + fname +" ,you registered successfully");
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                
                
            } else {
                
                String errorMessage = "User Available";
                HttpSession regSession = request.getSession();
                regSession.setAttribute("RegError", errorMessage);
                response.sendRedirect("Registration.jsp");
                out.println("<script type=\"text/javascript\">");
                out.println("alert('User already registered');");
                out.println("</script>");
                
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
