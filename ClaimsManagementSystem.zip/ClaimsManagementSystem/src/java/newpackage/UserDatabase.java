package newpackage;
import java.util.Random;
import java.sql.*;

public class UserDatabase {
    Connection con ;

    public UserDatabase(Connection con) {
        this.con = con;
    }
    
    //for register user 
    public boolean saveUser(User user){
        boolean set=false;

        
        try{
             
            //Insert register data to database
            String query = "insert into user(fname,lname,cno,email,Gender,dob,addr,nominee_count,insurance_type,insurance_amount,password,max_claim_amount) values(?,?,?,?,?,?,?,?,?,?,?,?)";
           //PreparedStatement pt = this.con.prepareStatement(query,PreparedStatement);
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, user.getFname());
           pt.setString(2, user.getLname());
           pt.setString(3, user.getCno());
           pt.setString(4, user.getEmail());
           pt.setString(5, user.getGender());
           pt.setString(6, user.getDob());
           pt.setString(7, user.getAddr());
           pt.setString(8, user.getNominee_count());
           pt.setString(9, user.getInsurance_type());
           pt.setString(10, user.getInsurance_amount());
           pt.setString(11, user.getPassword());
           pt.setString(12, user.getMaxi());
 
           pt.executeUpdate();
           /*ResultSet rs=pt.get;
            if(rs.next()){
                System.out.println(rs.getInt(1));
                cust_id=rs.getInt(1);
            }*/
           
            set=true;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return set;
        //return cust_id;
    }
    
    //user login
    public User login(String email, String pass){
        User usr=null;
        try{
            String query ="select * from user where email=? and password=?";
            PreparedStatement pst = this.con.prepareStatement(query);
            pst.setString(1, email);//in 1st position we pass email
            pst.setString(2, pass);
            
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                usr = new User();
                usr.setCust_id(rs.getString("cust_id"));
                usr.setFname(rs.getString("fname"));
                usr.setLname(rs.getString("lname"));
                usr.setEmail(rs.getString("email"));
                usr.setPassword(rs.getString("password"));
                
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return usr;
    }
    
    public boolean updateUser(User user){
        boolean updated = false;
        
 
        try{
                    
            //update data to database
            String query = "update user set fname=?,lname=?,cno=?,email=?,Gender=?,dob=?,addr=?,nominee_count=?,insurance_type=?,insurance_amount=?,max_claim_amount=?,updated_by=? where cust_id=? ";
          
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, user.getFname());
           pt.setString(2, user.getLname());
           pt.setString(3, user.getCno());
           pt.setString(4, user.getEmail());
           pt.setString(5, user.getGender());
           pt.setString(6, user.getDob());
           pt.setString(7, user.getAddr());
           pt.setString(8, user.getNominee_count());
           pt.setString(9, user.getInsurance_type());
           pt.setString(10, user.getInsurance_amount());
           //pt.setString(11,user.getPassword());
           pt.setString(11, user.getMaxi());
            pt.setString(12, user.getUpdated_by());
           pt.setString(13,user.getCust_id());
          
                      

           pt.executeUpdate();
           
           updated = true;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return updated;
    }
    
    public int claimUser(User user){
       int claim_id=0;

        try{
             
            //Insert register data to database
            String query = "insert into claim_process(cust_id, insurance_type, claim_reason, final_claim_amount, request_date,insurance_amount) values(?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
           
           pt.setString(1,user.getCust_id());
           pt.setString(2, user.getInsurance_type());
           pt.setString(3, user.getClaim_reason());
           pt.setString(4, user.getFinal_claim_amount());
           pt.setString(5, user.getRequest_date());
           pt.setString(6, user.getInsurance_amount());

           pt.executeUpdate();
            ResultSet rs=pt.getGeneratedKeys();
            if(rs.next()){
                System.out.println(rs.getInt(1));
                claim_id=rs.getInt(1);
            }
           
        }catch(SQLException e){
            e.printStackTrace();
        }
        return claim_id;
    }
    public boolean processUser(User user){
        boolean set = false;

        
        try{
             
            //Insert register data to database
            String query = "insert into claim(cust_id, claim_id, doc_1,doc_2,doc_3,decision,reject_reason,final_claim_amount,claim_status) values(?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           
           pt.setString(1,user.getCust_id());
           pt.setString(2,user.getClaim_id());
           pt.setString(3, user.getDoc1());
           pt.setString(4, user.getDoc2());
           pt.setString(5, user.getDoc3());
           pt.setString(6, user.getDecision());
           pt.setString(7, user.getReject_reason());
           pt.setString(8, user.getFinal_claim_amount());
           pt.setString(9, user.getClaim_status());
 
           pt.executeUpdate();
           
           set = true;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return set;
    }
}
    
    
   